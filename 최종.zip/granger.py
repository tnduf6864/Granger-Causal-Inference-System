from tracemalloc import start
from flask import Flask, render_template, url_for, request
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import adfuller 
from statsmodels.tsa.stattools import kpss  
from statsmodels.tsa.stattools import grangercausalitytests
from datetime import datetime
import datetime
import time

app = Flask(__name__)

@app.route("/")
@app.route("/main")
def index():    
    return render_template('main.html')

@app.route("/select_list")
def list():     
    return  render_template('select_list.html')

@app.route("/select_period")
def period():    
    return  render_template('select_period.html')

@app.route("/result")
def result():    
    keyword = request.args.get('keyword')    
    list = keyword.split('=')

    import granger_module
    timeSeries1 = pd.read_csv('./csv/'+ list[0] + '.csv')#, encoding='cp949') # csv파일 업로드 후 사용하려니 자꾸 오류발생해서 드라이브에 연결함 사용하실 때 수정바람
    timeSeries2 = pd.read_csv('./csv/president.csv', header=None)

    S, NS = granger_module.granger(timeSeries1, timeSeries2, list[0], list[2], list[4])
    
    pvalue = 0.05
    start = '2020-02-18'
    end = '2022-03-19'
    
    a1=[]
    b1=[]
    c1=[]
    d1=[]

    a2=[]
    b2=[]
    c2=[]
    d2=[]

    print(1+S[1][0]['ssr_ftest'][1])
    for i in range(1,13):
    #정상성 체크안한 시계열        
        a1.append(round(NS[i][0]['ssr_ftest'][1],4))        
        b1.append(round(NS[i][0]['ssr_chi2test'][1],4))
        c1.append(round(NS[i][0]['lrtest'][1],4))
        d1.append(round(NS[i][0]['params_ftest'][1],4))        
    #정상 시계열
        a2.append(round(S[i][0]['ssr_ftest'][1],4))        
        b2.append(round(S[i][0]['ssr_chi2test'][1],4))
        c2.append(round(S[i][0]['lrtest'][1],4))
        d2.append(round(S[i][0]['params_ftest'][1],4))        
    
    return  render_template('result.html', list1=[a1,b1,c1,d1], list2=[a2,b2,c2,d2])

@app.route("/test")
def t1():
    return  render_template('test.html')    

@app.route('/test2')
def t2():
    return  render_template('test2.html')    

@app.route('/test3')
def t3():
    return  render_template('test3.html')    

app.run(debug=True)


 